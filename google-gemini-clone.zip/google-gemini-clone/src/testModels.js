import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI("YOUR_API_KEY");

async function test() {
  try {
    const models = await genAI.listModels();
    console.log("Available Models: \n");
    models.models.forEach((m) => console.log(m.name));
  } catch (err) {
    console.error("Error listing models:", err);
  }
}

test();
