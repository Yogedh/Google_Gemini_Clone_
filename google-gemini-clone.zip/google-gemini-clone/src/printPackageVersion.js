import pkg from "@google/generative-ai/package.json";

console.log("Installed SDK version:");
console.log(pkg.version);
