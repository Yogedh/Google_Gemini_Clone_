import {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} from "@google/generative-ai";

const API_KEY = "AIzaSyCx_-0hqlBt630EzoZLK0fZlsAro8G9T8c";
const MODEL_NAME = "gemini-2.0-flash"; // ✔ fully supported by SDK 0.24.1

const generationConfig = {
  temperature: 0.9,
  maxOutputTokens: 2048,
};

async function runChat(prompt) {
  try {
    const genAI = new GoogleGenerativeAI(API_KEY);

    const model = genAI.getGenerativeModel({
      model: MODEL_NAME,
      generationConfig,
    });

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Something went wrong!";
  }
}

export default runChat;
